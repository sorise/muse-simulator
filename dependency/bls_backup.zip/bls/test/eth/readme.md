# data

The files in this directory are generated from [eth2.0-spec-tests](https://github.com/ethereum/eth2.0-spec-tests/tree/master/tests/general/phase0/bls)

sign.txt is converted by `cvt_sign.py`.
fast_aggregate_verify.txt is converted by `cvt_fast_agg.py`.
