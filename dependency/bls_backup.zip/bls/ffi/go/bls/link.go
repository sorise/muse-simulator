package bls

/*
#cgo CFLAGS:-I ../../../include -I ../../../mcl/include
#cgo LDFLAGS:-lmcl -L../../../lib -L../../../mcl/lib
*/
import "C"
