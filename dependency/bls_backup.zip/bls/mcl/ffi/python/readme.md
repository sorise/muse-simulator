# sample for Python

## SHE (2 Level HE)

```
make she_test
```

## Lifted ElGamal Encryption

```
make she_test_g1only
```

