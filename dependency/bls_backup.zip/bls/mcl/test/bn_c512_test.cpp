#include <mcl/bn512.hpp>
using namespace mcl::bn512;
#define MCLBN_DEFINE_STRUCT
#define MCLBN_FP_UNIT_SIZE 8
#include "bn_c_test.hpp"

