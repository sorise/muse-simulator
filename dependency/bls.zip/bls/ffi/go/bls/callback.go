package bls

/*
// exported from bls.go
unsigned int wrapReadRandGo(void *buf, unsigned int n);
int wrapReadRandCgo(void *self, void *buf, unsigned int n)
{
	(void)self;
	return wrapReadRandGo(buf, n);
}
*/
import "C"
