# divSmallX

Check the max difference between x and (x / (y+1)) * y

```
python3 divsmallx-diff.py
```
It's okay for y >= 1 << ((sizeof(Unit) * 8) / 2).
