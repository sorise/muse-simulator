#define MCLBN_FP_UNIT_SIZE 4
#include "bls_test.hpp"

